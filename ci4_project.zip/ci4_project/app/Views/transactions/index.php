<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Money Tracker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg bg-warning">
  <div class="container">
    <a class="navbar-brand fw-bold text-white" href="/transactions">💰 Money Tracker</a>
    <div>
      <span class="me-3 text-white">Hi, <?= session()->get('user_name') ?></span>
      <a href="/logout" class="btn btn-light btn-sm rounded-pill">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">

  <?php if(session()->getFlashdata('success')): ?>
  <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
  <?php endif; ?>

  <!-- Ringkasan Keuangan -->
  <div class="row text-center mb-4">
    <div class="col-md-4">
      <div class="card bg-success text-white rounded-4 shadow-sm">
        <div class="card-body">
          <h5>Pemasukan</h5>
          <h3>Rp <?= number_format($totalIncome, 0, ',', '.') ?></h3>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card bg-danger text-white rounded-4 shadow-sm">
        <div class="card-body">
          <h5>Pengeluaran</h5>
          <h3>Rp <?= number_format($totalExpense, 0, ',', '.') ?></h3>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card bg-info text-white rounded-4 shadow-sm">
        <div class="card-body">
          <h5>Saldo Akhir</h5>
          <h3>Rp <?= number_format($balance, 0, ',', '.') ?></h3>
        </div>
      </div>
    </div>
  </div>

  <!-- Filter Bulan -->
  <form method="get" class="mb-4">
    <label class="form-label fw-semibold">Filter Bulan:</label>
    <select name="month" class="form-select w-25 d-inline" onchange="this.form.submit()">
      <option value="">Semua Bulan</option>
      <?php for ($m = 1; $m <= 12; $m++): ?>
      <option value="<?= $m ?>" <?= ($month == $m ? 'selected' : '') ?>>
        <?= date("F", mktime(0,0,0,$m,1)) ?>
      </option>
      <?php endfor; ?>
    </select>
  </form>

  <div class="text-end mb-3">
    <a href="/transactions/create" class="btn btn-primary rounded-pill">+ Tambah Transaksi</a>
  </div>

  <!-- Tabel -->
  <div class="card shadow-sm rounded-4">
    <div class="card-body">
      <table class="table table-bordered text-center align-middle">
        <thead class="table-warning">
          <tr>
            <th>Tanggal</th>
            <th>Kategori</th>
            <th>Deskripsi</th>
            <th>Jenis</th>
            <th>Nominal</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($transactions as $t): ?>
          <tr>
            <td><?= $t['date'] ?></td>
            <td><?= $t['category'] ?></td>
            <td><?= $t['description'] ?></td>
            <td><?= ucfirst($t['type']) ?></td>
            <td>Rp <?= number_format($t['amount'], 0, ',', '.') ?></td>
            <td>
              <a href="/transactions/edit/<?= $t['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
              <a href="/transactions/delete/<?= $t['id'] ?>" class="btn btn-sm btn-danger"
                onclick="return confirm('Hapus data ini?')">Hapus</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Grafik Batang di bawah tabel -->
 <div class="my-5">
  <h5 class="text-center fw-bold">Grafik Pemasukan vs Pengeluaran</h5>
  <div style="max-width: 400px; margin: auto;">
    <canvas id="chartSummary" height="200"></canvas>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('chartSummary');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Pemasukan', 'Pengeluaran'],
    datasets: [{
      label: 'Statistik Bulan Ini',
      data: [<?= $totalIncome ?>, <?= $totalExpense ?>]
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false
  }
});
</script>
