<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tambah Transaksi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card shadow rounded-4 border-0">
          <div class="card-body p-4">
            <h4 class="fw-bold text-primary mb-3 text-center">Tambah Transaksi</h4>

            <form action="/transactions/store" method="post">
              <?= csrf_field() ?>

              <div class="mb-3">
                <label>Tanggal</label>
                <input type="date" name="date" class="form-control" required>
              </div>

              <div class="mb-3">
                <label>Kategori</label>
                <input type="text" name="category" class="form-control" placeholder="Contoh: Makan, Gaji">
              </div>

              <div class="mb-3">
                <label>Deskripsi</label>
                <textarea name="description" class="form-control" rows="2" placeholder="Opsional"></textarea>
              </div>

              <div class="mb-3">
                <label>Jenis</label>
                <select name="type" class="form-select" required>
                  <option value="income">Pemasukan</option>
                  <option value="expense">Pengeluaran</option>
                </select>
              </div>

              <div class="mb-3">
                <label>Nominal (Rp)</label>
                <input type="number" name="amount" class="form-control" step="0.01" required>
              </div>

              <div class="d-flex justify-content-between">
                <a href="/transactions" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-success">Simpan</button>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

</body>
</html>
