<?php

namespace App\Controllers;
use App\Models\TransactionModel;

class Transaction extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $user_id = session()->get('user_id');
        $month = $this->request->getGet('month');

        $model = new TransactionModel();
        $builder = $model->where('user_id', $user_id);

        if ($month) {
            $builder->where('MONTH(date)', $month);
        }

        $data['transactions'] = $builder->orderBy('date', 'DESC')->findAll();

        // --- Pemasukan ---
        $incomeModel = new TransactionModel();
        $incomeModel->where('user_id', $user_id)->where('type', 'income');
        if ($month) {
            $incomeModel->where('MONTH(date)', $month);
        }
        $data['totalIncome'] = $incomeModel->selectSum('amount')->first()['amount'] ?? 0;

        // --- Pengeluaran ---
        $expenseModel = new TransactionModel();
        $expenseModel->where('user_id', $user_id)->where('type', 'expense');
        if ($month) {
            $expenseModel->where('MONTH(date)', $month);
        }
        $data['totalExpense'] = $expenseModel->selectSum('amount')->first()['amount'] ?? 0;

        $data['balance'] = $data['totalIncome'] - $data['totalExpense'];
        $data['month'] = $month;

        return view('transactions/index', $data);
    }

    public function create()
    {
        return view('transactions/create');
    }

    public function store()
    {
        $model = new TransactionModel();
        $model->insert([
            'user_id' => session()->get('user_id'),
            'date' => $this->request->getPost('date'),
            'category' => $this->request->getPost('category'),
            'description' => $this->request->getPost('description'),
            'type' => $this->request->getPost('type'),
            'amount' => $this->request->getPost('amount'),
        ]);
        return redirect()->to('/transactions')->with('success', 'Transaksi berhasil ditambahkan!');
    }

    public function edit($id)
    {
        $model = new TransactionModel();
        $data['transaction'] = $model->find($id);
        if (!$data['transaction']) return redirect()->to('/transactions');
        return view('transactions/edit', $data);
    }

    public function update($id)
    {
        $model = new TransactionModel();
        $model->update($id, [
            'date' => $this->request->getPost('date'),
            'category' => $this->request->getPost('category'),
            'description' => $this->request->getPost('description'),
            'type' => $this->request->getPost('type'),
            'amount' => $this->request->getPost('amount'),
        ]);
        return redirect()->to('/transactions')->with('success', 'Transaksi berhasil diupdate!');
    }

    public function delete($id)
    {
        $model = new TransactionModel();
        $model->delete($id);
        return redirect()->to('/transactions')->with('success', 'Transaksi berhasil dihapus!');
    }
}
