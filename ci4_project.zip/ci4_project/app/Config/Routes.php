<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Auth Routes
$routes->get('/register', 'Auth::register');
$routes->post('/register', 'Auth::processRegister');
$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::processLogin');
$routes->get('/logout', 'Auth::logout');

// Transactions Routes
$routes->get('/', 'Transaction::index'); // Homepage langsung ke transaksi
$routes->get('/transactions', 'Transaction::index');
$routes->get('/transactions/create', 'Transaction::create');
$routes->post('/transactions/store', 'Transaction::store');
$routes->get('/transactions/edit/(:num)', 'Transaction::edit/$1');
$routes->post('/transactions/update/(:num)', 'Transaction::update/$1');
$routes->get('/transactions/delete/(:num)', 'Transaction::delete/$1');
